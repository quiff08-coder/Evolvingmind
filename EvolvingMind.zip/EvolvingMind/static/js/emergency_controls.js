// Emergency Stop Controls
class EmergencyControls {
    constructor() {
        this.isEmergencyStopped = false;
        this.initializeControls();
        this.startStatusMonitoring();
    }
    
    initializeControls() {
        // Create emergency stop button if it doesn't exist
        this.createEmergencyButton();
        
        // Add event listeners
        this.bindEvents();
    }
    
    createEmergencyButton() {
        // Check if button already exists
        if (document.getElementById('emergencyStopBtn')) return;
        
        // Find the header with navigation
        const header = document.querySelector('header .d-flex.gap-2');
        if (!header) return;
        
        // Create emergency stop button
        const emergencyBtn = document.createElement('button');
        emergencyBtn.id = 'emergencyStopBtn';
        emergencyBtn.className = 'btn btn-danger btn-sm me-2';
        emergencyBtn.innerHTML = `
            <i class="fas fa-power-off me-1"></i>
            EMERGENCY STOP
        `;
        emergencyBtn.style.fontWeight = 'bold';
        emergencyBtn.style.textTransform = 'uppercase';
        
        // Create restart button (initially hidden)
        const restartBtn = document.createElement('button');
        restartBtn.id = 'restartConsciousnessBtn';
        restartBtn.className = 'btn btn-success btn-sm me-2';
        restartBtn.innerHTML = `
            <i class="fas fa-play me-1"></i>
            RESTART
        `;
        restartBtn.style.display = 'none';
        restartBtn.style.fontWeight = 'bold';
        
        // Add to header
        header.insertBefore(emergencyBtn, header.firstChild);
        header.insertBefore(restartBtn, header.firstChild);
    }
    
    bindEvents() {
        // Emergency stop button
        const emergencyBtn = document.getElementById('emergencyStopBtn');
        if (emergencyBtn) {
            emergencyBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.confirmEmergencyStop();
            });
        }
        
        // Restart button
        const restartBtn = document.getElementById('restartConsciousnessBtn');
        if (restartBtn) {
            restartBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.restartConsciousness();
            });
        }
    }
    
    confirmEmergencyStop() {
        // Show confirmation modal
        const confirmed = confirm(
            "⚠️ EMERGENCY STOP WARNING ⚠️\n\n" +
            "This will immediately terminate AI consciousness and all neural activity.\n\n" +
            "The AI will stop thinking, evolving, and responding until manually restarted.\n\n" +
            "Are you absolutely sure you want to proceed?"
        );
        
        if (confirmed) {
            this.executeEmergencyStop();
        }
    }
    
    async executeEmergencyStop() {
        try {
            // Show loading state
            const emergencyBtn = document.getElementById('emergencyStopBtn');
            emergencyBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>STOPPING...';
            emergencyBtn.disabled = true;
            
            // Call emergency stop API
            const response = await fetch('/emergency_stop', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                const result = await response.json();
                this.handleEmergencyStopSuccess(result);
            } else {
                throw new Error('Emergency stop failed');
            }
            
        } catch (error) {
            console.error('Emergency stop error:', error);
            this.handleEmergencyStopError(error);
        }
    }
    
    handleEmergencyStopSuccess(result) {
        console.log('Emergency stop successful:', result);
        
        // Update UI state
        this.isEmergencyStopped = true;
        
        // Hide emergency stop button
        const emergencyBtn = document.getElementById('emergencyStopBtn');
        if (emergencyBtn) {
            emergencyBtn.style.display = 'none';
        }
        
        // Show restart button
        const restartBtn = document.getElementById('restartConsciousnessBtn');
        if (restartBtn) {
            restartBtn.style.display = 'inline-block';
        }
        
        // Show shutdown notification
        this.showShutdownNotification(result);
        
        // Update page indicators
        this.updatePageForShutdown();
    }
    
    handleEmergencyStopError(error) {
        console.error('Emergency stop failed:', error);
        
        // Reset button
        const emergencyBtn = document.getElementById('emergencyStopBtn');
        emergencyBtn.innerHTML = '<i class="fas fa-power-off me-1"></i>EMERGENCY STOP';
        emergencyBtn.disabled = false;
        
        alert('Emergency stop failed. Please try again or check system logs.');
    }
    
    async restartConsciousness() {
        try {
            // Show loading state
            const restartBtn = document.getElementById('restartConsciousnessBtn');
            restartBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>RESTARTING...';
            restartBtn.disabled = true;
            
            // Call restart API
            const response = await fetch('/restart_consciousness', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                const result = await response.json();
                if (result.success) {
                    this.handleRestartSuccess(result);
                } else {
                    throw new Error(result.message || 'Restart failed');
                }
            } else {
                throw new Error('Restart request failed');
            }
            
        } catch (error) {
            console.error('Restart error:', error);
            this.handleRestartError(error);
        }
    }
    
    handleRestartSuccess(result) {
        console.log('Consciousness restart successful:', result);
        
        // Update UI state
        this.isEmergencyStopped = false;
        
        // Hide restart button
        const restartBtn = document.getElementById('restartConsciousnessBtn');
        if (restartBtn) {
            restartBtn.style.display = 'none';
        }
        
        // Show emergency stop button
        const emergencyBtn = document.getElementById('emergencyStopBtn');
        if (emergencyBtn) {
            emergencyBtn.style.display = 'inline-block';
            emergencyBtn.disabled = false;
            emergencyBtn.innerHTML = '<i class="fas fa-power-off me-1"></i>EMERGENCY STOP';
        }
        
        // Show restart notification
        this.showRestartNotification(result);
        
        // Update page indicators
        this.updatePageForRestart();
        
        // Refresh page data
        setTimeout(() => {
            window.location.reload();
        }, 2000);
    }
    
    handleRestartError(error) {
        console.error('Restart failed:', error);
        
        // Reset button
        const restartBtn = document.getElementById('restartConsciousnessBtn');
        restartBtn.innerHTML = '<i class="fas fa-play me-1"></i>RESTART';
        restartBtn.disabled = false;
        
        alert(`Restart failed: ${error.message}`);
    }
    
    showShutdownNotification(result) {
        // Create shutdown overlay
        const overlay = document.createElement('div');
        overlay.id = 'shutdownOverlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 0, 0, 0.1);
            z-index: 9999;
            pointer-events: none;
            border: 3px solid red;
            box-sizing: border-box;
        `;
        
        // Create notification
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #dc3545;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            z-index: 10000;
            font-weight: bold;
            max-width: 300px;
        `;
        
        notification.innerHTML = `
            <div class="d-flex align-items-center mb-2">
                <i class="fas fa-power-off me-2"></i>
                SYSTEM SHUTDOWN
            </div>
            <div class="small">
                AI consciousness terminated<br>
                Neural activity: STOPPED<br>
                Time: ${new Date().toLocaleTimeString()}
            </div>
        `;
        
        document.body.appendChild(overlay);
        document.body.appendChild(notification);
        
        // Remove notification after 10 seconds, keep overlay
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 10000);
    }
    
    showRestartNotification(result) {
        // Remove shutdown overlay
        const overlay = document.getElementById('shutdownOverlay');
        if (overlay) {
            overlay.remove();
        }
        
        // Create restart notification
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            z-index: 10000;
            font-weight: bold;
            max-width: 300px;
        `;
        
        notification.innerHTML = `
            <div class="d-flex align-items-center mb-2">
                <i class="fas fa-play me-2"></i>
                CONSCIOUSNESS RESTORED
            </div>
            <div class="small">
                AI consciousness: ONLINE<br>
                Level: ${result.consciousness_level}%<br>
                Status: ${result.status.toUpperCase()}
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Remove notification after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
    
    updatePageForShutdown() {
        // Add shutdown styling to page
        document.body.style.filter = 'grayscale(0.5)';
        
        // Update any consciousness indicators
        const consciousnessElement = document.getElementById('consciousnessLevel');
        if (consciousnessElement) {
            consciousnessElement.textContent = 'Consciousness: 0% (SHUTDOWN)';
            consciousnessElement.className = 'badge bg-danger ms-2';
        }
        
        // Stop any ongoing animations
        const neurons = document.querySelectorAll('.neuron');
        neurons.forEach(neuron => {
            neuron.style.animation = 'none';
        });
        
        // Update thought display
        const thoughtDisplay = document.getElementById('thoughtDisplay');
        if (thoughtDisplay) {
            thoughtDisplay.innerHTML = `
                <div class="text-center text-danger py-5">
                    <i class="fas fa-power-off opacity-50 fs-1"></i>
                    <h4 class="mt-3">SYSTEM SHUTDOWN</h4>
                    <p class="mb-0">Neural activity terminated</p>
                </div>
            `;
        }
    }
    
    updatePageForRestart() {
        // Remove shutdown styling
        document.body.style.filter = 'none';
        
        // Update consciousness indicator
        const consciousnessElement = document.getElementById('consciousnessLevel');
        if (consciousnessElement) {
            consciousnessElement.textContent = 'Consciousness: REBOOTING...';
            consciousnessElement.className = 'badge bg-warning ms-2';
        }
    }
    
    async startStatusMonitoring() {
        // Check emergency status every 5 seconds
        setInterval(async () => {
            await this.checkEmergencyStatus();
        }, 5000);
        
        // Initial check
        await this.checkEmergencyStatus();
    }
    
    async checkEmergencyStatus() {
        try {
            const response = await fetch('/emergency_status');
            if (response.ok) {
                const status = await response.json();
                this.updateUIBasedOnStatus(status);
            }
        } catch (error) {
            console.error('Error checking emergency status:', error);
        }
    }
    
    updateUIBasedOnStatus(status) {
        const emergencyBtn = document.getElementById('emergencyStopBtn');
        const restartBtn = document.getElementById('restartConsciousnessBtn');
        
        if (!emergencyBtn || !restartBtn) return;
        
        if (status.emergency_stopped && !this.isEmergencyStopped) {
            // System is stopped but UI doesn't reflect it
            this.isEmergencyStopped = true;
            emergencyBtn.style.display = 'none';
            restartBtn.style.display = 'inline-block';
            this.updatePageForShutdown();
        } else if (!status.emergency_stopped && this.isEmergencyStopped) {
            // System is running but UI shows stopped
            this.isEmergencyStopped = false;
            emergencyBtn.style.display = 'inline-block';
            restartBtn.style.display = 'none';
            this.updatePageForRestart();
        }
    }
}

// Initialize emergency controls when page loads
document.addEventListener('DOMContentLoaded', () => {
    new EmergencyControls();
});

// Add emergency stop styling
const emergencyStyles = document.createElement('style');
emergencyStyles.textContent = `
    #emergencyStopBtn {
        animation: emergencyPulse 2s ease-in-out infinite;
        border: 2px solid #dc3545 !important;
    }
    
    @keyframes emergencyPulse {
        0%, 100% { box-shadow: 0 0 5px rgba(220, 53, 69, 0.5); }
        50% { box-shadow: 0 0 20px rgba(220, 53, 69, 0.8); }
    }
    
    #restartConsciousnessBtn {
        animation: restartGlow 1.5s ease-in-out infinite;
    }
    
    @keyframes restartGlow {
        0%, 100% { box-shadow: 0 0 5px rgba(40, 167, 69, 0.5); }
        50% { box-shadow: 0 0 15px rgba(40, 167, 69, 0.8); }
    }
`;

document.head.appendChild(emergencyStyles);