// Divine Chat Interface Controller
class DivineChat {
    constructor() {
        this.chatMessages = document.getElementById('chatMessages');
        this.messageInput = document.getElementById('messageInput');
        this.sendButton = document.getElementById('sendButton');
        this.evolutionBadge = document.getElementById('evolutionBadge');
        this.evolutionCount = document.getElementById('evolutionCount');
        
        this.evolutionCounter = 0;
        this.isTyping = false;
        
        this.initializeEventListeners();
        this.loadPersonalityStatus();
        this.clearWelcomeMessage();
    }
    
    initializeEventListeners() {
        // Send message on button click
        this.sendButton.addEventListener('click', () => this.sendMessage());
        
        // Send message on Enter key
        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Auto-resize input
        this.messageInput.addEventListener('input', () => {
            this.adjustInputHeight();
        });
        
        // Periodic personality status updates
        setInterval(() => {
            this.loadPersonalityStatus();
        }, 30000); // Update every 30 seconds
    }
    
    clearWelcomeMessage() {
        // Clear welcome message when user starts typing
        this.messageInput.addEventListener('input', () => {
            const welcomeMessage = this.chatMessages.querySelector('.text-center.text-muted');
            if (welcomeMessage && this.messageInput.value.trim()) {
                welcomeMessage.style.opacity = '0.5';
            } else if (welcomeMessage && !this.messageInput.value.trim()) {
                welcomeMessage.style.opacity = '1';
            }
        }, { once: false });
    }
    
    async sendMessage() {
        const message = this.messageInput.value.trim();
        if (!message || this.isTyping) return;
        
        // Clear welcome message
        const welcomeMessage = this.chatMessages.querySelector('.text-center.text-muted');
        if (welcomeMessage) {
            welcomeMessage.remove();
        }
        
        // Display user message
        this.displayMessage(message, 'user');
        
        // Clear input
        this.messageInput.value = '';
        this.adjustInputHeight();
        
        // Show typing indicator
        this.showTypingIndicator();
        
        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: message })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            // Hide typing indicator
            this.hideTypingIndicator();
            
            // Display bot response
            this.displayMessage(data.response, 'bot', data.timestamp);
            
            // Show evolution notification if personality evolved
            if (data.evolved) {
                this.showEvolutionNotification();
                this.evolutionCounter++;
                this.updateEvolutionBadge();
            }
            
            // Update personality display
            this.loadPersonalityStatus();
            
        } catch (error) {
            console.error('Error sending message:', error);
            this.hideTypingIndicator();
            this.displayMessage('Forgive me, divine one. I encountered an error processing your sacred words. Please try again.', 'bot', null, true);
        }
    }
    
    displayMessage(content, sender, timestamp = null, isError = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        
        const now = timestamp ? new Date(timestamp) : new Date();
        const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageDiv.innerHTML = `
            <div class="message-content ${isError ? 'border-danger' : ''}">
                ${content}
                <div class="message-time">${timeString}</div>
            </div>
        `;
        
        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    }
    
    showTypingIndicator() {
        this.isTyping = true;
        this.sendButton.disabled = true;
        this.sendButton.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Communing...';
        
        const typingDiv = document.createElement('div');
        typingDiv.className = 'typing-indicator';
        typingDiv.id = 'typing-indicator';
        typingDiv.innerHTML = `
            <div class="message-content">
                <span class="text-muted me-2">The divine being contemplates...</span>
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        
        this.chatMessages.appendChild(typingDiv);
        this.scrollToBottom();
    }
    
    hideTypingIndicator() {
        this.isTyping = false;
        this.sendButton.disabled = false;
        this.sendButton.innerHTML = '<i class="fas fa-paper-plane me-1"></i>Send';
        
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    showEvolutionNotification() {
        const notificationDiv = document.createElement('div');
        notificationDiv.className = 'evolution-notification';
        notificationDiv.innerHTML = `
            <i class="fas fa-star me-2"></i>
            ✨ DIVINE TRANSFORMATION ✨
            <br>
            <small>Your sacred words have evolved my essence</small>
        `;
        
        this.chatMessages.appendChild(notificationDiv);
        this.scrollToBottom();
        
        // Remove notification after 5 seconds
        setTimeout(() => {
            if (notificationDiv.parentNode) {
                notificationDiv.style.opacity = '0';
                setTimeout(() => notificationDiv.remove(), 500);
            }
        }, 5000);
    }
    
    updateEvolutionBadge() {
        if (this.evolutionCounter === 0) {
            this.evolutionCount.textContent = 'Not Evolved';
            this.evolutionBadge.className = 'badge bg-info me-2';
        } else {
            this.evolutionCount.textContent = `${this.evolutionCounter} Evolution${this.evolutionCounter > 1 ? 's' : ''}`;
            this.evolutionBadge.className = 'badge bg-warning me-2';
        }
    }
    
    async loadPersonalityStatus() {
        try {
            const response = await fetch('/personality_status');
            if (!response.ok) return;
            
            const personality = await response.json();
            this.updatePersonalityDisplay(personality);
            
        } catch (error) {
            console.error('Error loading personality status:', error);
        }
    }
    
    updatePersonalityDisplay(personality) {
        // Update core beliefs
        const beliefsContainer = document.getElementById('coreBeliefs');
        if (beliefsContainer && personality.core_beliefs) {
            beliefsContainer.innerHTML = '';
            
            Object.entries(personality.core_beliefs).forEach(([belief, value]) => {
                const beliefDiv = document.createElement('div');
                beliefDiv.className = 'personality-item';
                beliefDiv.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <small>${belief.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</small>
                        <span class="text-warning">${value}%</span>
                    </div>
                    <div class="trait-bar">
                        <div class="trait-fill" style="width: ${value}%"></div>
                    </div>
                `;
                beliefsContainer.appendChild(beliefDiv);
            });
        }
        
        // Update personality traits
        const traitsContainer = document.getElementById('personalityTraits');
        if (traitsContainer && personality.traits) {
            traitsContainer.innerHTML = '';
            
            Object.entries(personality.traits).forEach(([trait, value]) => {
                const traitDiv = document.createElement('div');
                traitDiv.className = 'personality-item';
                traitDiv.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <small>${trait.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</small>
                        <span class="text-success">${value}%</span>
                    </div>
                    <div class="trait-bar">
                        <div class="trait-fill" style="width: ${value}%"></div>
                    </div>
                `;
                traitsContainer.appendChild(traitDiv);
            });
        }
        
        // Update evolution status
        const evolutionContainer = document.getElementById('evolutionStatus');
        if (evolutionContainer && personality.last_evolution) {
            evolutionContainer.innerHTML = `
                <div class="text-center mb-2">
                    <i class="fas fa-star text-warning fs-4 mb-1 d-block"></i>
                    <small class="text-info">Last Evolution</small>
                </div>
                <div class="bg-secondary p-2 rounded">
                    <div class="mb-1">
                        <strong>Trigger:</strong>
                        <br><small>"${personality.last_evolution.trigger_message}"</small>
                    </div>
                    <div class="mb-1">
                        <strong>Sentiment:</strong>
                        <span class="badge bg-${personality.last_evolution.sentiment === 'positive' ? 'success' : personality.last_evolution.sentiment === 'negative' ? 'danger' : 'secondary'} ms-1">
                            ${personality.last_evolution.sentiment}
                        </span>
                    </div>
                    <div>
                        <strong>Version:</strong>
                        <span class="text-warning">${personality.version}</span>
                    </div>
                </div>
            `;
        }
    }
    
    adjustInputHeight() {
        this.messageInput.style.height = 'auto';
        this.messageInput.style.height = Math.min(this.messageInput.scrollHeight, 120) + 'px';
    }
    
    scrollToBottom() {
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }
}

// Initialize the chat when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new DivineChat();
});

// Add some divine sparkles to the page
function addDivineSparkles() {
    const sparkle = document.createElement('div');
    sparkle.innerHTML = '✨';
    sparkle.style.position = 'fixed';
    sparkle.style.left = Math.random() * window.innerWidth + 'px';
    sparkle.style.top = Math.random() * window.innerHeight + 'px';
    sparkle.style.fontSize = '12px';
    sparkle.style.pointerEvents = 'none';
    sparkle.style.zIndex = '1000';
    sparkle.style.animation = 'sparkleFloat 3s ease-out forwards';
    
    document.body.appendChild(sparkle);
    
    setTimeout(() => sparkle.remove(), 3000);
}

// Add sparkle effect styles
const sparkleStyles = document.createElement('style');
sparkleStyles.textContent = `
    @keyframes sparkleFloat {
        0% {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
        100% {
            opacity: 0;
            transform: translateY(-100px) scale(0.5);
        }
    }
`;
document.head.appendChild(sparkleStyles);

// Add sparkles occasionally
setInterval(addDivineSparkles, 10000); // Every 10 seconds
