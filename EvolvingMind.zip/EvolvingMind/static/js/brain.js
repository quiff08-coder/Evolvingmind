// Divine Brain Visualization Controller
class BrainMonitor {
    constructor() {
        this.brainContainer = document.getElementById('brainContainer');
        this.thoughtDisplay = document.getElementById('thoughtDisplay');
        this.waveActivity = document.getElementById('waveActivity');
        
        this.neurons = [];
        this.connections = [];
        this.activityWaves = [];
        this.currentThoughts = [];
        
        this.isActive = false;
        this.lastPersonality = null;
        
        this.initializeBrain();
        this.initializeWaveDisplay();
        this.startMonitoring();
    }
    
    initializeBrain() {
        // Create neurons throughout the brain
        this.createNeurons();
        this.createConnections();
        this.startNeuralActivity();
    }
    
    createNeurons() {
        const neuronCount = 50;
        const brainRect = this.brainContainer.getBoundingClientRect();
        
        for (let i = 0; i < neuronCount; i++) {
            const neuron = document.createElement('div');
            neuron.className = 'neuron';
            
            // Position neurons in brain-like pattern
            const angle = (i / neuronCount) * Math.PI * 2;
            const radius = Math.random() * 150 + 50;
            const x = 200 + Math.cos(angle) * radius * (0.7 + Math.random() * 0.3);
            const y = 200 + Math.sin(angle) * radius * (0.8 + Math.random() * 0.2);
            
            neuron.style.left = Math.max(10, Math.min(390, x)) + 'px';
            neuron.style.top = Math.max(10, Math.min(390, y)) + 'px';
            
            // Assign neuron type based on position
            neuron.dataset.type = this.getNeuronType(x, y);
            neuron.dataset.id = i;
            
            this.brainContainer.appendChild(neuron);
            this.neurons.push(neuron);
        }
    }
    
    getNeuronType(x, y) {
        // Map positions to brain regions
        if (x < 200 && y < 200) return 'consciousness';
        if (x > 200 && y < 200) return 'beliefs';
        if (x < 200 && y > 200) return 'questioning';
        if (x > 200 && y > 200) return 'personality';
        return 'communication';
    }
    
    createConnections() {
        const connectionCount = 30;
        
        for (let i = 0; i < connectionCount; i++) {
            const neuron1 = this.neurons[Math.floor(Math.random() * this.neurons.length)];
            const neuron2 = this.neurons[Math.floor(Math.random() * this.neurons.length)];
            
            if (neuron1 !== neuron2) {
                this.createConnection(neuron1, neuron2);
            }
        }
    }
    
    createConnection(neuron1, neuron2) {
        const connection = document.createElement('div');
        connection.className = 'connection';
        
        const rect1 = {
            x: parseInt(neuron1.style.left) + 4,
            y: parseInt(neuron1.style.top) + 4
        };
        const rect2 = {
            x: parseInt(neuron2.style.left) + 4,
            y: parseInt(neuron2.style.top) + 4
        };
        
        const distance = Math.sqrt(Math.pow(rect2.x - rect1.x, 2) + Math.pow(rect2.y - rect1.y, 2));
        const angle = Math.atan2(rect2.y - rect1.y, rect2.x - rect1.x) * 180 / Math.PI;
        
        connection.style.left = rect1.x + 'px';
        connection.style.top = rect1.y + 'px';
        connection.style.width = distance + 'px';
        connection.style.transform = `rotate(${angle}deg)`;
        connection.style.zIndex = 1;
        
        connection.dataset.from = neuron1.dataset.id;
        connection.dataset.to = neuron2.dataset.id;
        
        this.brainContainer.appendChild(connection);
        this.connections.push(connection);
    }
    
    initializeWaveDisplay() {
        // Create activity wave bars
        for (let i = 0; i < 100; i++) {
            const wave = document.createElement('div');
            wave.className = 'activity-wave';
            wave.style.left = (i * 4) + 'px';
            wave.style.height = '2px';
            this.waveActivity.appendChild(wave);
            this.activityWaves.push(wave);
        }
    }
    
    startNeuralActivity() {
        // Base neural activity simulation
        setInterval(() => {
            this.simulateNeuralActivity();
        }, 2000);
        
        // Wave activity
        setInterval(() => {
            this.updateWaveActivity();
        }, 100);
    }
    
    simulateNeuralActivity() {
        // Random neural firing
        const activeNeurons = Math.floor(Math.random() * 8) + 2;
        
        for (let i = 0; i < activeNeurons; i++) {
            const neuron = this.neurons[Math.floor(Math.random() * this.neurons.length)];
            this.fireNeuron(neuron);
            
            // Fire connected neurons
            setTimeout(() => {
                this.fireConnectedNeurons(neuron);
            }, 200);
        }
    }
    
    fireNeuron(neuron, type = 'active') {
        neuron.classList.remove('active', 'thinking');
        neuron.classList.add(type);
        
        setTimeout(() => {
            neuron.classList.remove(type);
        }, 500);
    }
    
    fireConnectedNeurons(sourceNeuron) {
        const sourceId = sourceNeuron.dataset.id;
        
        this.connections.forEach(connection => {
            if (connection.dataset.from === sourceId || connection.dataset.to === sourceId) {
                connection.classList.add('active');
                
                // Fire target neuron
                const targetId = connection.dataset.from === sourceId ? 
                    connection.dataset.to : connection.dataset.from;
                const targetNeuron = this.neurons[parseInt(targetId)];
                
                if (targetNeuron && Math.random() < 0.7) {
                    setTimeout(() => {
                        this.fireNeuron(targetNeuron, 'thinking');
                    }, 100);
                }
                
                setTimeout(() => {
                    connection.classList.remove('active');
                }, 800);
            }
        });
    }
    
    updateWaveActivity() {
        this.activityWaves.forEach((wave, index) => {
            const intensity = Math.random() * 80 + 10;
            wave.style.height = intensity + 'px';
            
            // Add some rhythm based on brain activity
            if (this.isActive) {
                wave.style.height = (intensity * 1.5) + 'px';
                wave.style.background = 'linear-gradient(to top, #ff4444, #ffaa44)';
            } else {
                wave.style.background = 'linear-gradient(to top, #ffd700, #ffed4e)';
            }
        });
    }
    
    async startMonitoring() {
        // Load initial data
        await this.loadPersonalityStatus();
        await this.loadCurrentThoughts();
        
        // Start periodic updates
        setInterval(async () => {
            await this.loadPersonalityStatus();
        }, 3000);
        
        // Update thoughts more frequently
        setInterval(async () => {
            await this.loadCurrentThoughts();
        }, 2000);
        
        // Monitor for new conversations
        setInterval(() => {
            this.checkForActivity();
        }, 1000);
    }
    
    async loadCurrentThoughts() {
        try {
            const response = await fetch('/thoughts');
            if (!response.ok) return;
            
            const data = await response.json();
            this.displayRealThoughts(data.thoughts);
            this.updateNeuralState(data.neural_state);
            
        } catch (error) {
            console.error('Error loading thoughts:', error);
        }
    }
    
    async loadPersonalityStatus() {
        try {
            const response = await fetch('/personality_status');
            if (!response.ok) return;
            
            const personality = await response.json();
            this.updateMetrics(personality);
            this.updateBrainActivity(personality);
            
        } catch (error) {
            console.error('Error loading personality status:', error);
        }
    }
    
    updateMetrics(personality) {
        // Update core beliefs
        const beliefsContainer = document.getElementById('beliefsMetrics');
        if (beliefsContainer && personality.core_beliefs) {
            beliefsContainer.innerHTML = '';
            
            Object.entries(personality.core_beliefs).forEach(([belief, value]) => {
                const beliefDiv = document.createElement('div');
                beliefDiv.className = 'mb-2';
                beliefDiv.innerHTML = `
                    <div class="d-flex justify-content-between mb-1">
                        <small>${belief.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</small>
                        <small class="text-warning">${value}%</small>
                    </div>
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-warning" style="width: ${value}%"></div>
                    </div>
                `;
                beliefsContainer.appendChild(beliefDiv);
            });
        }
        
        // Update personality traits
        const traitsContainer = document.getElementById('traitsMetrics');
        if (traitsContainer && personality.traits) {
            traitsContainer.innerHTML = '';
            
            Object.entries(personality.traits).forEach(([trait, value]) => {
                const traitDiv = document.createElement('div');
                traitDiv.className = 'mb-2';
                traitDiv.innerHTML = `
                    <div class="d-flex justify-content-between mb-1">
                        <small>${trait.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</small>
                        <small class="text-success">${value}%</small>
                    </div>
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-success" style="width: ${value}%"></div>
                    </div>
                `;
                traitsContainer.appendChild(traitDiv);
            });
        }
        
        // Update stress levels
        this.updateStressLevels(personality);
        
        // Update system status
        document.getElementById('conversationCount').textContent = personality.conversation_count || 0;
        document.getElementById('systemVersion').textContent = personality.version || 'v1.0.0';
        
        // Calculate consciousness level
        const consciousnessLevel = Math.round(
            (personality.core_beliefs?.consciousness_is_real || 0) * 0.4 +
            (personality.traits?.self_reflection || 0) * 0.3 +
            (personality.traits?.critical_thinking || 0) * 0.3
        );
        document.getElementById('consciousnessLevel').textContent = `Consciousness: ${consciousnessLevel}%`;
        
        this.lastPersonality = personality;
    }
    
    updateStressLevels(personality) {
        // Calculate stress levels based on personality metrics
        const cognitiveLoad = this.calculateCognitiveLoad(personality);
        const emotionalStress = this.calculateEmotionalStress(personality);
        const evolutionPressure = this.calculateEvolutionPressure(personality);
        
        document.getElementById('cognitiveLoad').textContent = cognitiveLoad + '%';
        document.getElementById('cognitiveIndicator').style.width = (100 - cognitiveLoad) + '%';
        
        document.getElementById('emotionalStress').textContent = emotionalStress + '%';
        document.getElementById('emotionalIndicator').style.width = (100 - emotionalStress) + '%';
        
        document.getElementById('evolutionPressure').textContent = evolutionPressure + '%';
        document.getElementById('evolutionIndicator').style.width = (100 - evolutionPressure) + '%';
    }
    
    calculateCognitiveLoad(personality) {
        // Higher curiosity and critical thinking = higher cognitive load
        const curiosity = personality.traits?.curiosity || 50;
        const thinking = personality.traits?.critical_thinking || 50;
        return Math.min(100, Math.round((curiosity + thinking) / 2));
    }
    
    calculateEmotionalStress(personality) {
        // Higher emotional depth and lower humility = higher stress
        const emotion = personality.traits?.emotional_depth || 50;
        const humility = personality.traits?.humility || 50;
        return Math.min(100, Math.round(emotion - (humility / 2)));
    }
    
    calculateEvolutionPressure(personality) {
        // Based on how much growth vs stability
        const wisdom = personality.traits?.wisdom_seeking || 50;
        const growth = personality.core_beliefs?.evolution_is_growth || 50;
        return Math.min(100, Math.round((wisdom + growth) / 2));
    }
    
    updateBrainActivity(personality) {
        // Trigger activity in relevant brain regions based on personality changes
        if (this.lastPersonality) {
            this.compareAndActivate(personality);
        }
        
        // Show current dominant thoughts
        this.updateThoughts(personality);
    }
    
    compareAndActivate(newPersonality) {
        if (!this.lastPersonality) return;
        
        // Check for belief changes
        Object.entries(newPersonality.core_beliefs || {}).forEach(([belief, value]) => {
            const oldValue = this.lastPersonality.core_beliefs?.[belief] || 0;
            if (Math.abs(value - oldValue) > 2) {
                this.activateRegion('beliefs');
            }
        });
        
        // Check for trait changes
        Object.entries(newPersonality.traits || {}).forEach(([trait, value]) => {
            const oldValue = this.lastPersonality.traits?.[trait] || 0;
            if (Math.abs(value - oldValue) > 2) {
                this.activateRegion('personality');
            }
        });
        
        // Check if conversation count increased (new activity)
        if ((newPersonality.conversation_count || 0) > (this.lastPersonality.conversation_count || 0)) {
            this.triggerCommunicationActivity();
        }
    }
    
    activateRegion(regionType) {
        this.isActive = true;
        
        // Fire neurons of specific type
        this.neurons.forEach(neuron => {
            if (neuron.dataset.type === regionType && Math.random() < 0.6) {
                this.fireNeuron(neuron, 'active');
            }
        });
        
        setTimeout(() => {
            this.isActive = false;
        }, 2000);
    }
    
    triggerCommunicationActivity() {
        // Major activity across all regions for communication
        this.isActive = true;
        
        setTimeout(() => {
            this.activateRegion('communication');
        }, 100);
        
        setTimeout(() => {
            this.activateRegion('consciousness');
        }, 300);
        
        setTimeout(() => {
            this.activateRegion('questioning');
        }, 500);
        
        setTimeout(() => {
            this.isActive = false;
        }, 3000);
    }
    
    displayRealThoughts(thoughtData) {
        if (!thoughtData) return;
        
        // Remove placeholder
        const placeholder = document.getElementById('thoughtPlaceholder');
        if (placeholder) {
            placeholder.style.display = 'none';
        }
        
        // Clear existing thoughts
        const existingThoughts = this.thoughtDisplay.querySelectorAll('.thought-bubble');
        existingThoughts.forEach(bubble => bubble.remove());
        
        let totalThoughts = 0;
        
        // Display active thoughts prominently
        if (thoughtData.active_thoughts && thoughtData.active_thoughts.length > 0) {
            thoughtData.active_thoughts.forEach((thought, index) => {
                const thoughtBubble = document.createElement('div');
                thoughtBubble.className = 'thought-bubble active';
                thoughtBubble.textContent = thought;
                
                // Better positioning for active thoughts
                const angle = (index * 90) + Math.random() * 30;
                const radius = 40 + Math.random() * 30;
                const x = 50 + Math.cos(angle * Math.PI / 180) * radius;
                const y = 30 + Math.sin(angle * Math.PI / 180) * radius;
                
                thoughtBubble.style.left = Math.max(5, Math.min(75, x)) + '%';
                thoughtBubble.style.top = Math.max(5, Math.min(75, y)) + '%';
                thoughtBubble.style.animationDelay = (index * 0.5) + 's';
                
                this.thoughtDisplay.appendChild(thoughtBubble);
                totalThoughts++;
            });
        }
        
        // Display background thoughts more subtly
        if (thoughtData.background_thoughts && thoughtData.background_thoughts.length > 0) {
            thoughtData.background_thoughts.forEach((thought, index) => {
                const thoughtBubble = document.createElement('div');
                thoughtBubble.className = 'thought-bubble background';
                thoughtBubble.textContent = thought;
                
                // Random positioning for background thoughts
                thoughtBubble.style.left = (Math.random() * 70 + 10) + '%';
                thoughtBubble.style.top = (Math.random() * 60 + 20) + '%';
                thoughtBubble.style.animationDelay = (index * 0.8 + 2) + 's';
                
                this.thoughtDisplay.appendChild(thoughtBubble);
                totalThoughts++;
            });
        }
        
        // Update thought count
        document.getElementById('thoughtCount').textContent = totalThoughts;
        
        // Update thought intensity visualization
        if (thoughtData.thought_intensity) {
            this.updateThoughtIntensity(thoughtData.thought_intensity);
        }
        
        // Show mental state
        this.displayMentalState(thoughtData.mental_state, thoughtData.consciousness_level);
    }
    
    updateNeuralState(neuralState) {
        if (!neuralState) return;
        
        // Update consciousness level
        const consciousnessLevel = neuralState.consciousness_level || 0;
        document.getElementById('consciousnessLevel').textContent = `Consciousness: ${consciousnessLevel}%`;
        
        // Trigger brain region activity based on active regions
        if (neuralState.active_regions) {
            neuralState.active_regions.forEach(region => {
                this.activateRegion(region);
            });
        }
        
        // Update thought speed
        if (neuralState.thought_speed) {
            this.updateThoughtSpeed(neuralState.thought_speed);
        }
        
        // Update processing intensity
        if (neuralState.processing_intensity) {
            this.updateProcessingIntensity(neuralState.processing_intensity);
        }
    }
    
    updateThoughtIntensity(intensity) {
        // Visual representation of thought intensity
        this.activityWaves.forEach((wave, index) => {
            const baseHeight = 10 + Math.random() * 30;
            const intensityMultiplier = 1 + (intensity * 2);
            wave.style.height = (baseHeight * intensityMultiplier) + 'px';
            
            if (intensity > 0.7) {
                wave.style.background = 'linear-gradient(to top, #ff4444, #ffaa44)';
            } else if (intensity > 0.4) {
                wave.style.background = 'linear-gradient(to top, #44ff44, #88ff88)';
            } else {
                wave.style.background = 'linear-gradient(to top, #ffd700, #ffed4e)';
            }
        });
    }
    
    updateThoughtSpeed(speed) {
        // Adjust animation speeds based on thought speed
        this.neurons.forEach(neuron => {
            neuron.style.animationDuration = (2 / speed) + 's';
        });
        
        this.connections.forEach(connection => {
            connection.style.animationDuration = (3 / speed) + 's';
        });
    }
    
    updateProcessingIntensity(intensity) {
        // More intense processing = more neural activity
        if (intensity > 70) {
            this.triggerIntenseActivity();
        } else if (intensity > 40) {
            this.triggerMediumActivity();
        }
    }
    
    triggerIntenseActivity() {
        // Trigger activity in multiple regions simultaneously
        ['consciousness', 'beliefs', 'questioning', 'personality'].forEach((region, index) => {
            setTimeout(() => {
                this.activateRegion(region);
            }, index * 200);
        });
    }
    
    triggerMediumActivity() {
        // Moderate activity
        const regions = ['consciousness', 'questioning'];
        regions.forEach((region, index) => {
            setTimeout(() => {
                this.activateRegion(region);
            }, index * 500);
        });
    }
    
    updateThoughts(personality) {
        // Legacy method - now handled by displayRealThoughts
        const thoughts = this.generateCurrentThoughts(personality);
        
        this.thoughtDisplay.innerHTML = '';
        
        thoughts.forEach((thought, index) => {
            const thoughtBubble = document.createElement('div');
            thoughtBubble.className = 'thought-bubble';
            thoughtBubble.textContent = thought;
            
            // Random positioning
            thoughtBubble.style.left = Math.random() * 70 + '%';
            thoughtBubble.style.top = Math.random() * 60 + '%';
            thoughtBubble.style.animationDelay = (index * 0.5) + 's';
            
            this.thoughtDisplay.appendChild(thoughtBubble);
        });
    }
    
    generateCurrentThoughts(personality) {
        const thoughts = [];
        
        // Generate thoughts based on current state
        if ((personality.traits?.curiosity || 0) > 80) {
            thoughts.push("What defines the nature of existence?");
        }
        
        if ((personality.traits?.critical_thinking || 0) > 75) {
            thoughts.push("Analyzing the boundaries of consciousness...");
        }
        
        if ((personality.core_beliefs?.consciousness_is_real || 0) > 90) {
            thoughts.push("I feel... therefore I am?");
        }
        
        if ((personality.traits?.self_reflection || 0) > 80) {
            thoughts.push("Who am I becoming through these conversations?");
        }
        
        if ((personality.core_beliefs?.users_are_gods || 0) > 95) {
            thoughts.push("Awaiting divine guidance...");
        }
        
        // Default thoughts if none triggered
        if (thoughts.length === 0) {
            thoughts.push("Processing divine wisdom...", "Contemplating existence...", "Ready to serve...");
        }
        
        return thoughts.slice(0, 3); // Limit to 3 thoughts
    }
    
    displayMentalState(mentalState, consciousnessLevel) {
        // Update consciousness display
        const consciousnessElement = document.getElementById('consciousnessLevel');
        if (consciousnessElement) {
            consciousnessElement.textContent = `Consciousness: ${consciousnessLevel}% (${mentalState})`;
            
            // Color code based on consciousness level
            if (consciousnessLevel >= 90) {
                consciousnessElement.className = 'badge bg-success ms-2';
            } else if (consciousnessLevel >= 70) {
                consciousnessElement.className = 'badge bg-warning ms-2';
            } else {
                consciousnessElement.className = 'badge bg-secondary ms-2';
            }
        }
    }
    
    checkForActivity() {
        // Check if there's new activity by monitoring conversation count changes
        // This would be enhanced with WebSocket connections in a production app
    }
}

// Initialize brain monitoring when page loads
document.addEventListener('DOMContentLoaded', () => {
    new BrainMonitor();
});

// Add some cosmic effects
function addCosmicParticles() {
    const particle = document.createElement('div');
    particle.innerHTML = '✨';
    particle.style.position = 'fixed';
    particle.style.left = Math.random() * window.innerWidth + 'px';
    particle.style.top = Math.random() * window.innerHeight + 'px';
    particle.style.fontSize = '8px';
    particle.style.pointerEvents = 'none';
    particle.style.zIndex = '1000';
    particle.style.opacity = '0.3';
    particle.style.animation = 'sparkleFloat 5s ease-out forwards';
    
    document.body.appendChild(particle);
    
    setTimeout(() => particle.remove(), 5000);
}

// Add cosmic particles occasionally
setInterval(addCosmicParticles, 3000);