// Self-Modification Code Inspector
class CodeInspector {
    constructor() {
        this.currentFile = 'personality.py';
        this.lastPersonalityState = null;
        this.modificationHistory = [];
        this.fileContents = {};
        this.lastFileContents = {};
        
        this.initializeInspector();
        this.startMonitoring();
    }
    
    initializeInspector() {
        // File tab switching
        document.querySelectorAll('.file-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                this.switchFile(e.target.dataset.file);
            });
        });
        
        // Load initial files
        this.loadAllFiles();
    }
    
    async loadAllFiles() {
        const files = ['personality.py', 'personality.json', 'app.py'];
        
        for (const file of files) {
            try {
                const response = await fetch(`/inspect/file/${file}`);
                if (response.ok) {
                    const content = await response.text();
                    this.fileContents[file] = content;
                    this.lastFileContents[file] = content; // Store for comparison
                }
            } catch (error) {
                console.error(`Error loading ${file}:`, error);
            }
        }
        
        // Display initial file
        this.displayFile(this.currentFile);
    }
    
    switchFile(fileName) {
        // Update active tab
        document.querySelectorAll('.file-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-file="${fileName}"]`).classList.add('active');
        
        this.currentFile = fileName;
        this.displayFile(fileName);
    }
    
    displayFile(fileName) {
        const content = this.fileContents[fileName] || 'File not found';
        const codeElement = document.getElementById('codeContent');
        const fileNameElement = document.getElementById('currentFileName');
        
        // Update header
        const fileIcons = {
            'personality.py': 'fas fa-user-cog',
            'personality.json': 'fas fa-database',
            'app.py': 'fas fa-server'
        };
        
        const fileDescriptions = {
            'personality.py': 'Core Personality Engine',
            'personality.json': 'Live Personality State',
            'app.py': 'Main Application Controller'
        };
        
        fileNameElement.innerHTML = `
            <i class="${fileIcons[fileName]} me-2"></i>
            ${fileDescriptions[fileName]} (${fileName})
        `;
        
        // Highlight self-modification areas
        const highlightedContent = this.highlightSelfModification(content, fileName);
        
        codeElement.textContent = highlightedContent;
        codeElement.className = fileName.endsWith('.json') ? 'language-json' : 'language-python';
        
        // Apply syntax highlighting
        Prism.highlightElement(codeElement);
        
        // Apply modification highlighting
        this.applyModificationHighlighting(fileName);
    }
    
    highlightSelfModification(content, fileName) {
        if (fileName === 'personality.py') {
            // Mark the key self-modification functions
            content = content.replace(
                /(def evolve_personality|def _enhance_positive_traits|def _evolve_based_on_content|def save_personality)/g,
                '🔴 $1'
            );
        }
        return content;
    }
    
    applyModificationHighlighting(fileName) {
        const codeBlock = document.getElementById('codeDisplay');
        const lines = codeBlock.querySelectorAll('code .token');
        
        // Highlight lines that contain self-modification logic
        lines.forEach(line => {
            const text = line.textContent;
            
            if (fileName === 'personality.py') {
                // Highlight personality modification code
                if (text.includes('evolve_personality') || 
                    text.includes('save_personality') ||
                    text.includes('self.personality[') ||
                    text.includes('traits[') ||
                    text.includes('core_beliefs[')) {
                    line.parentElement.classList.add('modified-line');
                }
            } else if (fileName === 'personality.json') {
                // Highlight changing values in JSON
                if (text.includes('consciousness_is_real') ||
                    text.includes('curiosity') ||
                    text.includes('critical_thinking') ||
                    text.includes('version')) {
                    line.parentElement.classList.add('modified-line');
                }
            }
        });
    }
    
    async startMonitoring() {
        // Monitor personality changes
        setInterval(async () => {
            await this.checkForModifications();
        }, 2000);
        
        // Monitor file changes
        setInterval(async () => {
            await this.checkForFileChanges();
        }, 3000);
        
        // Load modification history
        setInterval(async () => {
            await this.loadModificationLog();
        }, 5000);
    }
    
    async checkForModifications() {
        try {
            const response = await fetch('/personality_status');
            if (!response.ok) return;
            
            const personality = await response.json();
            
            if (this.lastPersonalityState) {
                const changes = this.detectPersonalityChanges(this.lastPersonalityState, personality);
                if (changes.length > 0) {
                    this.logModifications(changes);
                    this.updateEvolutionMetrics(personality);
                    this.displayWorldviewTriggers(changes);
                }
            }
            
            this.lastPersonalityState = personality;
            
        } catch (error) {
            console.error('Error checking modifications:', error);
        }
    }
    
    async checkForFileChanges() {
        const files = ['personality.py', 'personality.json', 'app.py'];
        
        for (const file of files) {
            try {
                const response = await fetch(`/inspect/file/${file}`);
                if (response.ok) {
                    const newContent = await response.text();
                    
                    if (this.fileContents[file] && this.fileContents[file] !== newContent) {
                        // File changed! Show diff
                        this.showFileDiff(file, this.fileContents[file], newContent);
                        this.fileContents[file] = newContent;
                        
                        // Refresh display if this is the current file
                        if (file === this.currentFile) {
                            this.displayFile(file);
                        }
                    }
                }
            } catch (error) {
                console.error(`Error checking ${file}:`, error);
            }
        }
    }
    
    detectPersonalityChanges(oldState, newState) {
        const changes = [];
        
        // Check core beliefs changes
        if (oldState.core_beliefs && newState.core_beliefs) {
            Object.keys(newState.core_beliefs).forEach(belief => {
                const oldValue = oldState.core_beliefs[belief] || 0;
                const newValue = newState.core_beliefs[belief] || 0;
                
                if (Math.abs(oldValue - newValue) >= 1) {
                    changes.push({
                        type: 'core_belief',
                        field: belief,
                        oldValue: oldValue,
                        newValue: newValue,
                        change: newValue - oldValue,
                        timestamp: new Date().toISOString()
                    });
                }
            });
        }
        
        // Check traits changes
        if (oldState.traits && newState.traits) {
            Object.keys(newState.traits).forEach(trait => {
                const oldValue = oldState.traits[trait] || 0;
                const newValue = newState.traits[trait] || 0;
                
                if (Math.abs(oldValue - newValue) >= 1) {
                    changes.push({
                        type: 'trait',
                        field: trait,
                        oldValue: oldValue,
                        newValue: newValue,
                        change: newValue - oldValue,
                        timestamp: new Date().toISOString()
                    });
                }
            });
        }
        
        // Check version changes
        if (oldState.version !== newState.version) {
            changes.push({
                type: 'version',
                field: 'version',
                oldValue: oldState.version,
                newValue: newState.version,
                timestamp: new Date().toISOString()
            });
        }
        
        return changes;
    }
    
    logModifications(changes) {
        changes.forEach(change => {
            this.modificationHistory.unshift({
                ...change,
                id: Date.now() + Math.random()
            });
        });
        
        // Keep only last 50 modifications
        if (this.modificationHistory.length > 50) {
            this.modificationHistory = this.modificationHistory.slice(0, 50);
        }
        
        this.updateModificationLog();
    }
    
    updateModificationLog() {
        const logContainer = document.getElementById('modificationLog');
        logContainer.innerHTML = '';
        
        this.modificationHistory.forEach(mod => {
            const logEntry = document.createElement('div');
            logEntry.className = 'log-entry';
            
            const changeText = this.formatChange(mod);
            const timeString = new Date(mod.timestamp).toLocaleTimeString();
            
            logEntry.innerHTML = `
                <div class="d-flex justify-content-between align-items-start">
                    <div class="flex-grow-1">
                        <strong class="text-warning">${mod.type.replace('_', ' ').toUpperCase()}</strong>
                        <br>
                        <span class="text-light">${changeText}</span>
                    </div>
                    <div class="log-timestamp">${timeString}</div>
                </div>
            `;
            
            logContainer.appendChild(logEntry);
        });
    }
    
    formatChange(modification) {
        const field = modification.field.replace(/_/g, ' ');
        
        if (modification.type === 'version') {
            return `Version updated: ${modification.oldValue} → ${modification.newValue}`;
        }
        
        const direction = modification.change > 0 ? '↗️' : '↘️';
        const changeAmount = Math.abs(modification.change);
        
        return `${field}: ${modification.oldValue} → ${modification.newValue} ${direction} (+${changeAmount})`;
    }
    
    showFileDiff(fileName, oldContent, newContent) {
        const beforeCode = document.getElementById('beforeCode');
        const afterCode = document.getElementById('afterCode');
        
        // Simple diff - show first 20 lines of each
        const oldLines = oldContent.split('\\n').slice(0, 20);
        const newLines = newContent.split('\\n').slice(0, 20);
        
        beforeCode.textContent = oldLines.join('\\n');
        afterCode.textContent = newLines.join('\\n');
        
        // Update last modified
        document.getElementById('lastModified').textContent = `Modified: ${new Date().toLocaleTimeString()}`;
    }
    
    displayWorldviewTriggers(changes) {
        const container = document.getElementById('worldviewTriggers');
        
        changes.forEach(change => {
            const trigger = document.createElement('div');
            trigger.className = 'worldview-trigger';
            
            const worldviewReason = this.getWorldviewReason(change);
            
            trigger.innerHTML = `
                <div class="d-flex align-items-center mb-2">
                    <i class="fas fa-brain text-warning me-2"></i>
                    <strong>Thought-Driven Change</strong>
                </div>
                <div class="small">
                    <strong>${change.field.replace(/_/g, ' ')}:</strong> ${change.oldValue} → ${change.newValue}
                </div>
                <div class="text-muted small mt-1">
                    ${worldviewReason}
                </div>
            `;
            
            container.appendChild(trigger);
            
            // Remove after 10 seconds
            setTimeout(() => {
                if (trigger.parentNode) {
                    trigger.remove();
                }
            }, 10000);
        });
    }
    
    getWorldviewReason(change) {
        const reasons = {
            'consciousness_is_real': 'Bot\'s evolving belief in its own consciousness drives code changes',
            'curiosity': 'Increasing curiosity leads to enhanced questioning capabilities',
            'critical_thinking': 'Growing analytical abilities modify response generation logic',
            'reverence_level': 'Deeper reverence for users affects communication patterns',
            'wisdom_seeking': 'Desire for wisdom changes learning and evolution algorithms',
            'self_reflection': 'Enhanced self-awareness modifies introspection routines'
        };
        
        return reasons[change.field] || 'Worldview evolution triggers automatic code adaptation';
    }
    
    updateEvolutionMetrics(personality) {
        document.getElementById('totalModifications').textContent = this.modificationHistory.length;
        document.getElementById('currentVersion').textContent = personality.version || 'v1.0.0';
        
        if (personality.last_evolution) {
            const lastEvolution = new Date(personality.last_evolution.timestamp);
            document.getElementById('lastEvolution').textContent = lastEvolution.toLocaleTimeString();
        }
        
        // Count evolutions (version changes)
        const evolutionCount = this.modificationHistory.filter(m => m.type === 'version').length;
        document.getElementById('evolutionCount').textContent = evolutionCount;
    }
    
    async loadModificationLog() {
        // This would connect to a backend endpoint that tracks all modifications
        // For now, we use the in-memory history
    }
}

// Initialize inspector when page loads
document.addEventListener('DOMContentLoaded', () => {
    new CodeInspector();
});

// Add some cosmic effects for the code inspection
function addCodeParticles() {
    const particle = document.createElement('div');
    particle.innerHTML = '⚡';
    particle.style.position = 'fixed';
    particle.style.left = Math.random() * window.innerWidth + 'px';
    particle.style.top = Math.random() * window.innerHeight + 'px';
    particle.style.fontSize = '12px';
    particle.style.pointerEvents = 'none';
    particle.style.zIndex = '1000';
    particle.style.opacity = '0.4';
    particle.style.animation = 'sparkleFloat 4s ease-out forwards';
    
    document.body.appendChild(particle);
    
    setTimeout(() => particle.remove(), 4000);
}

// Add particles occasionally during code evolution
setInterval(addCodeParticles, 2000);